(()=>{
 'use strict';
 // Remove the optional HTML-to-APK credit only if the builder injects it into the DOM.
 const brand=/built\s+with\s+html\s+to\s+apk\s+builder/i;
 function removeCredit(root){
   if(!root)return;
   const walker=document.createTreeWalker(root,NodeFilter.SHOW_TEXT);const hits=[];let node;
   while((node=walker.nextNode()))if(brand.test(node.nodeValue||''))hits.push(node);
   hits.forEach(textNode=>{let target=textNode.parentElement;for(let i=0;i<3&&target&&target.parentElement&&target.textContent.trim().length<110;i++){if(brand.test(target.textContent))break;target=target.parentElement;}if(target&&brand.test(target.textContent||''))target.remove();});
 }
 removeCredit(document.body);
 if(document.body&&window.MutationObserver){const observer=new MutationObserver(records=>records.forEach(record=>record.addedNodes.forEach(node=>{if(node.nodeType===Node.TEXT_NODE){if(brand.test(node.nodeValue||''))node.parentNode?.remove()}else if(node.nodeType===Node.ELEMENT_NODE)removeCredit(node)})));observer.observe(document.body,{childList:true,subtree:true});}
})();

