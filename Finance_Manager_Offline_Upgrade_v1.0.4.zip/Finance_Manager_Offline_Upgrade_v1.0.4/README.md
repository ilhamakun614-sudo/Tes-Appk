# Finance Manager Offline — Capacitor project 1.0.4

Paket ini adalah patch terarah atas proyek yang sudah ada. Versi 1.0.4 memperbaiki tombol Cetak / Simpan PDF pada halaman Statistik dengan jalur cetak native Capacitor dan fallback browser. Perbaikan multi-mata-uang dan kebijakan utang/piutang dari versi sebelumnya tetap dipertahankan.

## Perbaikan yang dipertahankan dari 1.0.3

- Catatan utang/piutang otomatis dihapus dari modul setelah saldo benar-benar lunas. Sebelum pembersihan data lama, aplikasi membuat backup penuh dan memeriksa bahwa snapshot memuat key kewajiban yang sama persis.
- Transaksi pembayaran tetap ada di ledger wallet. Transaksi tersebut diberi penanda perlindungan agar tetap tidak dapat diedit/dihapus dari menu transaksi umum walaupun catatan kewajibannya sudah dihapus.
- Tombol hapus catatan tersedia dari layar detail. Menghapus catatan yang sudah pernah dicicil hanya menghapus metadata kewajiban; transaksi pembayaran di ledger tetap ada dan dilindungi.
- Budget, laporan statistik dan PDF tahunan, ringkasan kategori/tag, grafik interaktif, jawaban asisten offline, widget harian, dan ringkasan utang/piutang serta net-worth dikonversi ke mata uang dasar memakai kurs offline tersimpan. Detail transaksi tetap menampilkan mata uang wallet asal.
- Setiap kewajiban menyimpan satuan mata uang awalnya. Pembayaran dari wallet mata uang lain dikonversi dengan kurs offline; cicilan baru menyimpan nilai ekuivalen pada mata uang kewajiban saat pembayaran agar perubahan kurs berikutnya tidak mengubah sisa cicilan baru.
- Tidak ada fitur A–E yang dibuat duplikat. Fitur yang sudah ada dipertahankan.

## Perbaikan cetak Statistik — 1.0.4

- Tombol Statistik kini membuat dokumen HTML laporan mandiri beserta CSS cetaknya, lalu memanggil `Printer.printHtml()`.
- Pada Android/iOS Capacitor, plugin membuka dialog cetak native. Pada web, plugin menggunakan dialog cetak browser.
- Jika plugin native tidak tersedia, pengguna mendapat pesan yang jelas; aplikasi tidak lagi mengandalkan `window.print()` yang dapat menjadi no-op pada WebView.
- Tombol menampilkan status sibuk selama proses dan dikembalikan setelah proses selesai.
- Plugin `@capgo/capacitor-printer` dipatok pada `8.1.8`, major version yang ditujukan untuk Capacitor 8. Plugin dibundel secara lokal oleh Vite; tidak ada CDN atau akses internet saat runtime.

### Build setelah patch printer

```sh
npm install
npm run build
npm test
npx cap sync android
```

Pastikan `npm run build` selesai sebelum `cap sync`, supaya modul printer masuk ke bundle lokal `www/js/fm-sqlite-center.js`. Setelah itu build ulang APK. Tidak perlu menghapus aplikasi lama atau data lokal untuk patch ini.

## Struktur utama

- `www/index.html`: shell aplikasi dan referensi aset lokal.
- `www/css/styles-01.css` … `styles-21.css`: gaya aplikasi yang telah ada.
- `www/js/app-01.js`, `app-02.js`: logika aplikasi lama beserta patch terarah.
- `src/sqlite-center.js`: UI pengelolaan database SQLite native.
- `src/migration-core.js`: pengumpulan data lokal, format snapshot, SHA-256, dan verifikasi.
- `src/print-helper.js`: jembatan ke plugin cetak native Capacitor, dibundel bersama modul SQLite agar tetap lokal/offline.
- `vite.config.js`: bundling modul plugin ke `www/js/fm-sqlite-center.js`.
- `tools/`: pemeriksaan proyek, tes regresi, dan tes inti snapshot/SQLite.

## Status penyimpanan — baca sebelum memasang

**SQLite pada versi 1.0.3 masih berupa snapshot vault terverifikasi, belum menjadi database utama transaksi harian.** Data transaksi harian masih memakai `localStorage`, sementara sebagian lampiran/media memakai `IndexedDB`. Panel Database & Migrasi menyalin key/value `localStorage` ke SQLite, membaca ulang hasilnya, lalu memverifikasi SHA-256. Proses snapshot tidak menghapus atau menimpa sumber `localStorage`.

Snapshot SQLite tidak sama dengan backup penuh aplikasi. Backup terenkripsi aplikasi memiliki jalur terpisah yang mencakup key `finance_*` dan arsip media IndexedDB. Ikuti panduan backup yang tersedia di aplikasi; jangan mengandalkan SQLite snapshot sebagai satu-satunya salinan.

**Jangan uninstall aplikasi lama, clear data, atau menjadikan SQLite sebagai satu-satunya sumber data sebelum migrasi domain penuh dan restore diuji di Android.**

## Kurs mata uang dan laporan

Nilai budget serta ringkasan transaksi yang ditampilkan dalam mata uang dasar menggunakan kurs yang tersimpan secara offline. Kurs tidak diperbarui otomatis. Beberapa laporan historis dan cicilan lama masih menghitung ulang data lama memakai kurs yang sedang tersimpan; transaksi reguler belum memiliki snapshot kurs per transaksi. Cicilan baru sudah membekukan ekuivalen pada mata uang kewajiban ketika pembayaran dicatat. Karena itu, perubahan kurs masih dapat mengubah ekuivalen nilai historis untuk data lama.

## Build dan verifikasi

Gunakan Node.js 22.12+ atau Node.js 24:

```sh
npm install
npm run build
npm test
npx cap add android   # hanya pertama kali
npx cap sync android
```

Untuk build APK debug dari proyek Android yang sudah ada:

```sh
npm run android:debug
```

`npm test` memeriksa struktur/sintaks proyek, tes core snapshot/SQLite, dan tes regresi terkait profil, ledger cicilan, kebijakan hapus otomatis, serta konversi budget. Tes ini belum menggantikan uji interaksi browser/WebView atau perangkat Android.

## Batasan yang belum diselesaikan

- SQLite belum menjadi sumber data langsung untuk transaksi.
- Tidak ada chart of accounts dan double-entry journal; ini bukan software akuntansi bisnis penuh.
- Kurs historis belum dikunci per transaksi.
- PIN aplikasi mengunci tampilan, bukan mengenkripsi `localStorage`.
- Database aktif belum dienkripsi at-rest; jalur backup terenkripsi terpisah.
- Notifikasi jatuh tempo masih bergantung pada aplikasi dibuka; scheduler notifikasi native belum diverifikasi.
- Biometrik native Android belum diimplementasikan.
- Build APK dan pengujian perangkat Android belum dilakukan di lingkungan audit ini.
- Jalur cetak native memerlukan instalasi dependency `@capgo/capacitor-printer` dan `npx cap sync android`; jika APK dibuat dari source sebelum tahap itu, tombol akan memberi pesan bahwa modul cetak belum aktif.

## Keamanan distribusi

APK debug hanya untuk pengujian. Rilis distribusi memerlukan signing key sendiri yang disimpan secara aman. Jaga repository tetap Private dan jangan commit file backup atau keystore.
