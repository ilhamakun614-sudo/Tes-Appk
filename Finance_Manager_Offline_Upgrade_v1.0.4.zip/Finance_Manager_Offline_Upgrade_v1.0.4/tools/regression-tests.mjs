import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const source = fs.readFileSync(path.join(root, 'www/js/app-01.js'), 'utf8');

// Test the actual profile loader source in a sandbox: corrupt JSON must not be overwritten.
const profileStart = source.indexOf('let v7ProfileRegistryCorrupt=false;');
const profileEnd = source.indexOf('let v7Profiles=v7LoadProfiles();', profileStart);
assert.ok(profileStart >= 0 && profileEnd > profileStart, 'profile loader source found');
const profileCode = source.slice(profileStart, profileEnd);
function profileSandbox(raw) {
  let writes = 0;
  const context = {
    storageReadBlocked: false,
    V7_PROFILES_KEY: 'finance_manager_v7_profiles',
    safeRead: () => raw,
    safeWrite: () => { writes++; return true; },
    v7FreshProfiles: () => ({ version: 7, activeId: 'personal', profiles: [{ id: 'personal', name: 'Pribadi' }] }),
    v7NormalizeProfiles: (value) => value,
    toast: () => {},
    setTimeout: () => 0,
  };
  vm.runInNewContext(`${profileCode}\nglobalThis.__inspect = () => { const loaded=v7LoadProfiles(); return {corrupt:v7ProfileRegistryCorrupt, loaded}; };`, context);
  return { ...context.__inspect(), writes };
}
const malformed = profileSandbox('{json-rusak');
assert.equal(malformed.corrupt, true, 'malformed profile registry enters protection mode');
assert.equal(malformed.writes, 0, 'malformed profile registry is never overwritten');
const healthy = profileSandbox(JSON.stringify({ version: 7, activeId: 'personal', profiles: [{ id: 'personal', name: 'Pribadi' }] }));
assert.equal(healthy.corrupt, false, 'valid profile registry stays writable');
assert.equal(healthy.writes, 1, 'valid profile registry may be normalized');

// Test the actual ledger guard source: linked installment transaction is blocked.
const guardStart = source.indexOf('function v12r3_unsafeToModify(id){');
const guardEnd = source.indexOf('const v12r3_previousDeleteTransaction=', guardStart);
assert.ok(guardStart >= 0 && guardEnd > guardStart, 'ledger guard source found');
const guardCode = source.slice(guardStart, guardEnd);
const guardContext = {
  data: { transactions: [{ id: 'pay-1', type: 'expense', amount: 50, walletId: 'w1', date: '2026-11-08' }] },
  v5State: { obligations: [{ id: 'ob-1', payments: [{ transactionId: 'pay-1' }] }] },
  v4WalletCurrency: () => 'IDR',
};
vm.runInNewContext(`${guardCode}\nglobalThis.__guard = v12r3_unsafeToModify;`, guardContext);
assert.equal(guardContext.__guard('pay-1'), true, 'installment-linked ledger transaction is protected');
guardContext.v5State.obligations = [];
assert.equal(guardContext.__guard('pay-1'), false, 'ordinary valid ledger transaction remains editable');
guardContext.data.transactions.push({ id: 'pay-1', type: 'income', amount: 50, walletId: 'w2', date: '2026-11-08' });
assert.equal(guardContext.__guard('pay-1'), true, 'duplicate transaction IDs remain protected');

// Paid debt/receivable records are removed from the obligation module only after a verified backup.
assert.doesNotMatch(source, /function v5KwhArchiveDialog\(\)/, 'paid archive UI is not present');
assert.doesNotMatch(source, /Riwayat Lunas/, 'no duplicate paid archive entry point is present');
assert.match(source, /nextState\.obligations=nextState\.obligations\.filter\(x=>x\.id!==id\)/, 'paid obligation metadata is removed');
assert.match(source, /nextData\.transactions\.push\(tx\)/, 'payment is retained in the main ledger');
assert.match(source, /t\.obligationPayment=true/, 'payment ledger rows remain protected after obligation deletion');
assert.match(source, /t\.obligationSettlement=true/, 'settlement evidence remains available for achievements');
assert.match(source, /function fmCreateVerifiedObligationBackup\(\)/, 'obligation changes require the shared full-backup verifier');
assert.match(source, /fmCreateVerifiedObligationBackup\(\);/, 'payment, manual deletion, and legacy cleanup call the full-backup verifier');
assert.match(source, /keys\[V5_STORAGE_KEY\]!==liveMetaRaw/, 'backup must contain the exact active obligation metadata');
assert.match(source, /liveData!==JSON\.stringify\(data\)/, 'backup must verify the active finance ledger before mutation');
assert.match(source, /v5DeleteObligation/);
assert.match(source, /if\(!v5WritePair\(nextData,next\)\)throw Error\('Penyimpanan gagal\. Catatan tidak dihapus\.'\)/, 'manual delete commits ledger markers and obligation state together');

// Execute the actual budget conversion helper with deterministic offline exchange-rate stubs.
const helperLine = source.split('\n').find((line) => line.startsWith('function fmBudgetConvertedAmount(t)'));
assert.ok(helperLine, 'budget currency conversion helper exists');
const currencyContext = {
  v4Meta: { baseCurrency: 'IDR' },
  v4WalletCurrency: (id) => id === 'usd-wallet' ? 'USD' : 'IDR',
  v4Convert: (amount, from, to) => from === to ? amount : (from === 'USD' && to === 'IDR' ? amount * 15000 : 0),
};
vm.runInNewContext(`${helperLine}\nglobalThis.__convert = fmBudgetConvertedAmount;`, currencyContext);
assert.equal(currencyContext.__convert({ amount: 2, walletId: 'usd-wallet' }), 30000, 'foreign wallet expense is converted to the configured base currency');
assert.equal(currencyContext.__convert({ amount: 25000, walletId: 'idr-wallet' }), 25000, 'base currency expense remains unchanged');
assert.equal(currencyContext.__convert({ amount: 'not-a-number', walletId: 'usd-wallet' }), 0, 'invalid expense amount is ignored');
assert.match(source, /reduce\(\(s,t\)=>s\+fmBudgetConvertedAmount\(t\),0\)/, 'category, daily, and monthly budget aggregates use converted amounts');


const obligationHelperNames = ['function fmObligationCurrency(o)', 'function fmObligationPaymentValue(p,o)', 'function fmObligationToBase(amount,o)'];
const obligationHelperLines = source.split('\n').filter(line => obligationHelperNames.some(name => line.startsWith(name)));
assert.equal(obligationHelperLines.length, 3, 'obligation multi-currency helpers exist');
const obligationCurrencyContext = {
  v4Meta: { baseCurrency: 'IDR' },
  v4WalletCurrency: (id) => ({ 'wallet-usd': 'USD', 'wallet-idr': 'IDR' }[id] || 'IDR'),
  v4Convert: (amount, from, to) => {
    const rates = { IDR: 1, USD: 15000 };
    return rates[from] && rates[to] ? amount * rates[from] / rates[to] : 0;
  }
};
vm.runInNewContext(`${obligationHelperLines.join('\n')}\nglobalThis.__paymentValue=fmObligationPaymentValue;globalThis.__toBase=fmObligationToBase;`, obligationCurrencyContext);
assert.equal(obligationCurrencyContext.__paymentValue({amount:150000,walletId:'wallet-idr'}, {currencyCode:'USD',walletId:'wallet-usd'}), 10, 'legacy cross-currency installment converts from payment wallet into obligation currency');
assert.equal(obligationCurrencyContext.__paymentValue({amount:150000,obligationAmount:10,obligationCurrency:'USD',transactionCurrency:'IDR',walletId:'wallet-idr'}, {currencyCode:'USD',walletId:'wallet-usd'}), 10, 'new installment uses its frozen obligation-currency equivalent');
assert.equal(obligationCurrencyContext.__toBase(10, {currencyCode:'USD',walletId:'wallet-usd'}), 150000, 'obligation totals convert into base currency');
const obligationWrapperStart = source.indexOf('v5ObligationPaid = function(o){', source.indexOf('function fmObligationInputNumber(amount)'));
const obligationWrapperEnd = source.indexOf('v5NormalizeState = function(input){', obligationWrapperStart);
assert.ok(obligationWrapperStart >= 0 && obligationWrapperEnd > obligationWrapperStart, 'obligation payment wrappers found');
const wrapperContext = {
  ...obligationCurrencyContext,
  v5ObligationPaid: (o) => (o.payments || []).reduce((sum,p) => sum + Number(p.amount || 0), 0),
  v5ObligationRemaining: (o) => Math.max(0, Number(o.amount) - (o.payments || []).reduce((sum,p) => sum + Number(p.amount || 0), 0)),
};
vm.runInNewContext(source.slice(obligationWrapperStart, obligationWrapperEnd) + '\nglobalThis.__paid=v5ObligationPaid;globalThis.__remaining=v5ObligationRemaining;', wrapperContext);
const foreignInstallment = { amount: 100, currencyCode: 'USD', walletId: 'wallet-usd', status: 'unpaid', payments: [{ amount: 150000, walletId: 'wallet-idr' }] };
assert.equal(wrapperContext.__paid(foreignInstallment), 10, 'actual obligation payment wrapper converts old IDR installment to USD obligation currency');
assert.equal(wrapperContext.__remaining(foreignInstallment), 90, 'actual remaining balance subtracts converted installment, not raw foreign amount');
const frozenInstallment = { amount: 100, currencyCode: 'USD', walletId: 'wallet-usd', status: 'unpaid', payments: [{ amount: 999999, obligationAmount: 10, obligationCurrency: 'USD', transactionCurrency: 'IDR', walletId: 'wallet-idr' }] };
assert.equal(wrapperContext.__paid(frozenInstallment), 10, 'actual payment wrapper prefers frozen obligation equivalent over later FX changes');
assert.match(source, /currencyCode:v4WalletCurrency\(wal\.input\.value\)/, 'new obligations retain their original currency code');
assert.match(source, /obligationAmount:equivalent,obligationCurrency,transactionCurrency:paymentCurrency/, 'new cross-currency payments freeze their converted obligation amount');
assert.match(source, /function fmCreateVerifiedObligationBackup\(\)/, 'verified full backup is available before obligation mutation');

// Net-worth and health summaries must convert an obligation by its preserved currencyCode,
// even if the wallet's current currency has since changed.
const debtSummaryLine = source.split('\n').find(line => line.startsWith('function v8OpenDebtAndReceivable()'));
assert.ok(debtSummaryLine, 'net-worth obligation summary source found');
const debtSummaryContext = {
  v5State: { obligations: [
    { id: 'd1', kind: 'debt', walletId: 'wallet-eur', currencyCode: 'USD' },
    { id: 'r1', kind: 'receivable', walletId: 'wallet-eur', currencyCode: 'USD' }
  ] },
  v5ObligationRemaining: () => 10,
  fmObligationToBase: (amount, obligation) => obligation.currencyCode === 'USD' ? amount * 15000 : amount,
  v4Convert: () => 999999,
  v4WalletCurrency: () => 'EUR',
  v4Meta: { baseCurrency: 'IDR' },
  v8Num: Number
};
vm.runInNewContext(`${debtSummaryLine}\nglobalThis.__summary=v8OpenDebtAndReceivable;`, debtSummaryContext);
const debtSummary = debtSummaryContext.__summary();
assert.equal(debtSummary.debts, 150000, 'debt net-worth total uses the original USD obligation currency');
assert.equal(debtSummary.receivables, 150000, 'receivable net-worth total uses the original USD obligation currency');

const assistantBlock = source.slice(source.indexOf('function v7Answer(question){'), source.indexOf('\nfunction v7AddChatMessage'));
assert.match(assistantBlock, /a\+fmBudgetConvertedAmount\(t\)/, 'offline assistant aggregates mixed-currency totals in base currency');
assert.match(assistantBlock, /fmBudgetConvertedAmount\(b\)-fmBudgetConvertedAmount\(a\)/, 'offline assistant ranks large transactions by converted values');
const annualBlock = source.slice(source.indexOf('function v10AnnualReport(){'), source.indexOf('\nfunction v10ThemeSettings'));
assert.match(annualBlock, /sum\+fmBudgetConvertedAmount\(t\)/, 'annual report summary converts to base currency');
assert.match(annualBlock, /v10Money\(t\.amount,code\)/, 'annual report detail retains each wallet transaction currency');
assert.match(source, /today=\(data\.transactions\|\|\[\]\)\.filter\(t=>t\.date===date&&t\.type==='expense'\)\.reduce\(\(s,t\)=>s\+fmBudgetConvertedAmount\(t\),0\)/, 'dashboard today-expense widget uses base currency conversion');
assert.match(source, /const convertRemaining=o=>\{const n=remaining\(o\);const value=typeof fmObligationToBase==='function'\?fmObligationToBase\(n,o\)/, 'net-worth obligation summary uses obligation currencyCode');

console.log('PASS: profile protection, linked-ledger protection, auto-delete and safe manual delete, full-backup verification, multi-currency budgets/reports/assistant/widgets, and multi-currency obligation installments/net-worth summaries.');
