import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const projectRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const errors = [];
const warnings = [];
const read = (rel) => fs.readFileSync(path.join(projectRoot, rel), 'utf8');

let pkg;
let config;
let html;
try { pkg = JSON.parse(read('package.json')); } catch (e) { errors.push(`package.json tidak valid: ${e.message}`); }
try { config = JSON.parse(read('capacitor.config.json')); } catch (e) { errors.push(`capacitor.config.json tidak valid: ${e.message}`); }
try { html = read('www/index.html'); } catch (e) { errors.push(`www/index.html tidak dapat dibaca: ${e.message}`); }

if (config) {
  if (!config.appId || !config.appName || !config.webDir) errors.push('Konfigurasi Capacitor wajib memiliki appId, appName, dan webDir.');
  else if (!fs.existsSync(path.join(projectRoot, config.webDir))) errors.push(`webDir tidak ditemukan: ${config.webDir}`);
}

if (html) {
  if (/\\n\s*<link/i.test(html)) errors.push('Ditemukan teks literal \\n sebelum elemen link di index.html.');
  if (/app-03\.js/i.test(html)) errors.push('index.html masih memuat app-03.js yang telah dihapus.');
  const refs = [...html.matchAll(/(?:src|href)=["']([^"']+)["']/gi)].map(m => m[1]);
  for (const ref of refs) {
    if (/^(?:https?:|data:|mailto:|tel:|#|javascript:)/i.test(ref)) continue;
    const clean = ref.split(/[?#]/)[0];
    if (!fs.existsSync(path.join(projectRoot, 'www', clean))) {
      if (clean === 'js/fm-sqlite-center.js' && fs.existsSync(path.join(projectRoot, 'src/sqlite-center.js'))) warnings.push('Bundle SQLite belum dibuat di www. Jalankan npm run build sebelum cap sync.');
      else errors.push(`Aset lokal tidak ditemukan: ${ref}`);
    }
  }
  const scripts = [...html.matchAll(/<script\b[^>]*\bsrc=["']([^"']+)["'][^>]*>/gi)].map(m => m[1]);
  for (const rel of scripts) {
    const abs = path.join(projectRoot, 'www', rel);
    if (!fs.existsSync(abs) && rel === 'js/fm-sqlite-center.js') continue;
    const checked = spawnSync(process.execPath, ['--check', abs], { encoding: 'utf8' });
    if (checked.status !== 0) errors.push(`Syntax check gagal pada ${rel}: ${(checked.stderr || checked.stdout || '').trim()}`);
  }
}

if (pkg) {
  if (!pkg.scripts?.build || !pkg.devDependencies?.vite) errors.push('Build Vite untuk modul SQLite native belum dikonfigurasi.');
  if (!pkg.dependencies?.['@capacitor-community/sqlite']) errors.push('Plugin SQLite Capacitor tidak terpasang sebagai dependency.');
  if (!pkg.scripts?.test) errors.push('Script npm test belum didefinisikan.');
  const allVersions = [...Object.values(pkg.dependencies || {}), ...Object.values(pkg.devDependencies || {})];
  if (allVersions.some(v => typeof v !== 'string' || !/^\d+\.\d+\.\d+$/.test(v))) warnings.push('Ada dependency yang versinya tidak dipatok secara exact.');
  if (!fs.existsSync(path.join(projectRoot, 'package-lock.json'))) warnings.push('package-lock.json belum tersedia; instalasi build belum sepenuhnya reproducible.');
}

for (const rel of ['src/sqlite-center.js', 'src/migration-core.js']) {
  const abs = path.join(projectRoot, rel);
  if (!fs.existsSync(abs)) { errors.push(`Sumber modul SQLite tidak ditemukan: ${rel}`); continue; }
  const checked = spawnSync(process.execPath, ['--check', abs], { encoding: 'utf8' });
  if (checked.status !== 0) errors.push(`Syntax check gagal pada ${rel}: ${(checked.stderr || checked.stdout || '').trim()}`);
}
const dbModule = fs.existsSync(path.join(projectRoot, 'src/sqlite-center.js')) ? read('src/sqlite-center.js') : '';
if (dbModule && (!dbModule.includes('executeSet(operations)') || !dbModule.includes('verifySnapshotEnvelope(readback)') || !dbModule.includes('localStorage'))) errors.push('Alur SQLite snapshot belum memiliki batch tulis, baca-ulang, dan validasi sumber.');
if (dbModule && (!dbModule.includes("execute('PRAGMA foreign_keys = ON;', false)") || !dbModule.includes("query('PRAGMA foreign_keys;')"))) errors.push('Foreign key SQLite harus diaktifkan di luar transaksi dan diverifikasi pada koneksi.');
if (dbModule && /localStorage\.(?:setItem|removeItem|clear)\s*\(/.test(dbModule)) errors.push('Modul migrasi SQLite tidak boleh mengubah atau menghapus sumber localStorage.');

const printHelperPath = path.join(projectRoot, 'src/print-helper.js');
if (!fs.existsSync(printHelperPath)) errors.push('Jembatan printer native tidak ditemukan: src/print-helper.js.');
else { const checked = spawnSync(process.execPath, ['--check', printHelperPath], { encoding: 'utf8' }); if (checked.status !== 0) errors.push(`Syntax check gagal pada src/print-helper.js: ${(checked.stderr || checked.stdout || '').trim()}`); }
if (!pkg?.dependencies?.['@capgo/capacitor-printer']) errors.push('Plugin cetak Capacitor native belum terdaftar sebagai dependency.');
if (!read('src/sqlite-center.js').includes("import './print-helper.js';")) errors.push('Jembatan printer belum dimasukkan ke entry Vite yang dimuat aplikasi.');
const viteConfig = path.join(projectRoot, 'vite.config.js');
if (!fs.existsSync(viteConfig)) errors.push('vite.config.js tidak ditemukan.');
else { const checked = spawnSync(process.execPath, ['--check', viteConfig], { encoding: 'utf8' }); if (checked.status !== 0) errors.push(`Syntax check gagal pada vite.config.js: ${(checked.stderr || checked.stdout || '').trim()}`); }
const coreTests = spawnSync(process.execPath, [path.join(projectRoot, 'tools/sqlite-core-tests.mjs')], { encoding: 'utf8' });
if (coreTests.status !== 0) errors.push(`Tes inti SQLite gagal: ${(coreTests.stdout || '') + (coreTests.stderr || '')}`);
const appSource = fs.existsSync(path.join(projectRoot, 'www/js/app-01.js')) ? read('www/js/app-01.js') : '';
if (appSource && !appSource.includes('async function v7PrintReport()')) errors.push('Handler cetak Statistik belum memakai alur async native/browser.');
if (appSource && !appSource.includes('printer.printHtml({name:safeTitle')) errors.push('Handler cetak Statistik belum memanggil printHtml.');
if (appSource && !appSource.includes('Modul cetak Android belum aktif')) errors.push('Fallback platform native tanpa plugin belum memberi pesan yang jelas.');

if (appSource && appSource.includes('function v5KwhArchiveDialog()')) errors.push('UI arsip lunas seharusnya tidak ada pada kebijakan hapus otomatis.');
if (appSource && !appSource.includes('function fmBudgetConvertedAmount(t)')) errors.push('Konversi mata uang budget tidak ditemukan.');
if (appSource && !appSource.includes('function fmObligationPaymentValue(p,o)')) errors.push('Konversi cicilan lintas mata uang tidak ditemukan.');
if (appSource && !appSource.includes('obligationAmount:equivalent,obligationCurrency,transactionCurrency:paymentCurrency')) errors.push('Snapshot konversi pembayaran kewajiban tidak ditemukan.');
if (appSource && !appSource.includes('function fmCreateVerifiedObligationBackup()')) errors.push('Verifikasi backup penuh sebelum perubahan kewajiban tidak ditemukan.');
if (appSource && appSource.includes('__kwhBaseRemaining(o)>')) errors.push('Daftar kewajiban masih memakai agregasi saldo lintas mata uang mentah.');
if (appSource && !appSource.includes('nextData.transactions.forEach(t=>{if(linkedIds.has(t.id))t.obligationPayment=true')) errors.push('Proteksi transaksi cicilan setelah penghapusan catatan tidak ditemukan.');
if (appSource && !appSource.includes('const linkedInstallment=Array.isArray(v5State?.obligations)')) errors.push('Proteksi transaksi terkait cicilan tidak ditemukan.');

if (warnings.length) for (const warning of warnings) console.warn(`WARN: ${warning}`);
if (errors.length) {
  for (const error of errors) console.error(`FAIL: ${error}`);
  process.exitCode = 1;
} else {
  console.log('PASS: package/config JSON, webDir, seluruh aset lokal, JavaScript syntax, dan patch integritas dasar.');
  console.log(`PASS: ${html ? [...html.matchAll(/<script\b[^>]*\bsrc=/gi)].length : 0} external script file(s) checked.`);
  const regressions = spawnSync(process.execPath, [path.join(projectRoot, 'tools/regression-tests.mjs')], { encoding: 'utf8' });
  if (regressions.status !== 0) {
    console.error((regressions.stdout || '') + (regressions.stderr || ''));
    process.exitCode = 1;
  } else {
    process.stdout.write(regressions.stdout);
  }
}
