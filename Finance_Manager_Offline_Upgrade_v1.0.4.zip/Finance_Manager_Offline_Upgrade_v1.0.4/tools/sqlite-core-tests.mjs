import assert from 'node:assert/strict';
import { webcrypto } from 'node:crypto';
import {
  collectStorageEntries,
  createSnapshotEnvelope,
  normalizeSnapshotEntries,
  verifySnapshotEnvelope,
  SNAPSHOT_LIMITS,
} from '../src/migration-core.js';

if (!globalThis.crypto) globalThis.crypto = webcrypto;

class MemoryStorage {
  constructor(entries = []) { this.items = new Map(entries); }
  get length() { return this.items.size; }
  key(index) { return [...this.items.keys()][index] ?? null; }
  getItem(key) { return this.items.has(String(key)) ? this.items.get(String(key)) : null; }
  setItem(key, value) { this.items.set(String(key), String(value)); }
  removeItem(key) { this.items.delete(String(key)); }
}

const storage = new MemoryStorage([
  ['finance_v1', JSON.stringify({ transactions: [{ id: 'tx-1', amount: 12000 }] })],
  ['finance_backup_last', '{"verified":true}'],
  ['fm_v12_restore_journal', '{"phase":"committed"}'],
  ['label', 'Ceng — data lokal'],
]);
const original = [...storage.items.entries()];
const collected = collectStorageEntries(storage);
assert.equal(collected.entries.length, 4, 'all origin localStorage entries are captured');
assert.deepEqual([...storage.items.entries()], original, 'snapshot collection never changes source storage');
assert.deepEqual(collected.entries.map((item) => item.key), [...collected.entries.map((item) => item.key)].sort(), 'keys are canonicalized');

const envelope = await createSnapshotEnvelope(collected.entries, { snapshotId: 'test-snapshot-1' });
const report = await verifySnapshotEnvelope(envelope);
assert.equal(report.valid, true);
assert.equal(report.keyCount, 4);
assert.equal(report.checksum, envelope.checksum);

const tamperedValue = structuredClone(envelope);
tamperedValue.entries[0].value += 'x';
await assert.rejects(() => verifySnapshotEnvelope(tamperedValue), /tidak cocok/);

const tamperedCount = structuredClone(envelope);
tamperedCount.keyCount += 1;
await assert.rejects(() => verifySnapshotEnvelope(tamperedCount), /Jumlah data snapshot tidak cocok/);

assert.throws(() => normalizeSnapshotEntries([{ key: 'a', value: '1' }, { key: 'a', value: '2' }]), /Key ganda/);
assert.throws(() => normalizeSnapshotEntries([{ key: 'large', value: '12345' }], { maxKeys: 2, maxBytes: 3 }), /melebihi batas/);
assert.throws(() => collectStorageEntries(new MemoryStorage([['x', 'a'], ['y', 'b']]), { maxKeys: 1, maxBytes: 100 }), /melebihi batas aman 1/);

console.log('PASS: read-only source collection, stable ordering, SHA-256 verification, tamper detection, duplicate-key rejection, and size limits.');
