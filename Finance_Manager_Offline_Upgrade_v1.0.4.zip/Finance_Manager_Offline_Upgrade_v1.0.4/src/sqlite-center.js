import './print-helper.js';
import { Capacitor } from '@capacitor/core';
import { CapacitorSQLite, SQLiteConnection } from '@capacitor-community/sqlite';
import {
  collectStorageEntries,
  createSnapshotEnvelope,
  formatBytes,
  verifySnapshotEnvelope,
} from './migration-core.js';

const DB_NAME = 'FinanceManagerOfflineVault';
const DB_VERSION = 1;
const APP_VERSION = '1.0.4';
const dbManager = new SQLiteConnection(CapacitorSQLite);
let dbConnection = null;
let dbReady = false;
let dbOpened = false;
let currentSnapshot = null;
let busy = false;

const SCHEMA_SQL = `
CREATE TABLE IF NOT EXISTS fm_schema_migrations (
  version INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  applied_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS fm_snapshots (
  snapshot_id TEXT PRIMARY KEY NOT NULL,
  format_version INTEGER NOT NULL,
  source TEXT NOT NULL,
  created_at TEXT NOT NULL,
  app_version TEXT NOT NULL,
  key_count INTEGER NOT NULL CHECK (key_count >= 0),
  byte_count INTEGER NOT NULL CHECK (byte_count >= 0),
  checksum TEXT NOT NULL CHECK (length(checksum) = 64),
  status TEXT NOT NULL CHECK (status IN ('staging','verified','failed')),
  verified_at TEXT,
  failure_note TEXT
);
CREATE TABLE IF NOT EXISTS fm_snapshot_items (
  snapshot_id TEXT NOT NULL,
  storage_key TEXT NOT NULL,
  storage_value TEXT NOT NULL,
  value_sha256 TEXT NOT NULL CHECK (length(value_sha256) = 64),
  byte_length INTEGER NOT NULL CHECK (byte_length >= 0),
  PRIMARY KEY (snapshot_id, storage_key),
  FOREIGN KEY (snapshot_id) REFERENCES fm_snapshots(snapshot_id) ON DELETE RESTRICT
);
CREATE INDEX IF NOT EXISTS idx_fm_snapshot_items_snapshot ON fm_snapshot_items(snapshot_id);
CREATE INDEX IF NOT EXISTS idx_fm_snapshots_status_created ON fm_snapshots(status, created_at);
CREATE TABLE IF NOT EXISTS fm_audit_events (
  event_id TEXT PRIMARY KEY NOT NULL,
  event_type TEXT NOT NULL,
  occurred_at TEXT NOT NULL,
  details_json TEXT NOT NULL
);
`;

function makeId() {
  return globalThis.crypto?.randomUUID ? globalThis.crypto.randomUUID() : `evt-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

function setStatus(message, state = 'info') {
  const status = document.getElementById('fmdbStatus');
  if (!status) return;
  status.textContent = message;
  status.dataset.state = state;
}

function showError(error) {
  const message = error instanceof Error ? error.message : String(error || 'Kesalahan tidak diketahui.');
  setStatus(`Gagal: ${message}`, 'error');
  console.error('[FM SQLite]', error);
}

async function getDatabase() {
  if (!Capacitor.isNativePlatform()) throw new Error('SQLite native hanya tersedia setelah aplikasi dibangun menjadi APK/iOS dengan plugin tersinkronisasi.');
  if (!dbConnection) {
    const state = await dbManager.isConnection(DB_NAME, false);
    if (!state?.result) await dbManager.createConnection(DB_NAME, false, 'no-encryption', DB_VERSION, false);
    dbConnection = await dbManager.retrieveConnection(DB_NAME, false);
  }
  if (!dbOpened) {
    await dbConnection.open();
    // SQLite ignores attempts to toggle foreign_keys inside a transaction.
    // Run this pragma outside a transaction, then verify it on this connection.
    await dbConnection.execute('PRAGMA foreign_keys = ON;', false);
    const foreignKeyState = readRows(await dbConnection.query('PRAGMA foreign_keys;'))[0];
    if (Number(foreignKeyState?.foreign_keys) !== 1) {
      throw new Error('SQLite tidak mengaktifkan foreign key pada koneksi ini. Snapshot dibatalkan.');
    }
    await dbConnection.execute(SCHEMA_SQL, true);
    await dbConnection.run(
      'INSERT OR IGNORE INTO fm_schema_migrations (version, name, applied_at) VALUES (?, ?, ?)',
      [DB_VERSION, 'snapshot-vault-and-audit-log', new Date().toISOString()],
    );
    dbOpened = true;
  }
  dbReady = true;
  return dbConnection;
}

function readRows(result) {
  if (Array.isArray(result?.values)) return result.values;
  if (Array.isArray(result)) return result;
  return [];
}

async function latestVerifiedSnapshot(db) {
  const result = await db.query(
    "SELECT snapshot_id, created_at, key_count, byte_count, checksum FROM fm_snapshots WHERE status = 'verified' ORDER BY created_at DESC LIMIT 1",
  );
  return readRows(result)[0] || null;
}

async function recordAudit(db, type, details) {
  await db.run(
    'INSERT INTO fm_audit_events (event_id, event_type, occurred_at, details_json) VALUES (?, ?, ?, ?)',
    [makeId(), type, new Date().toISOString(), JSON.stringify(details || {})],
  );
}

async function initialiseDatabase() {
  setStatus('Menghubungkan ke database SQLite native…', 'working');
  const db = await getDatabase();
  const latest = await latestVerifiedSnapshot(db);
  dbReady = true;
  setStatus(
    latest
      ? `SQLite siap · snapshot terverifikasi terakhir ${latest.key_count} key · ${formatBytes(latest.byte_count)}`
      : 'SQLite siap · belum ada snapshot data lama.',
    'success',
  );
  await refreshSummary(db);
  return db;
}

async function refreshSummary(db = dbConnection) {
  const summary = document.getElementById('fmdbSummary');
  if (!summary) return;
  if (!dbReady || !db) {
    summary.textContent = 'Database belum disiapkan.';
    return;
  }
  const latest = await latestVerifiedSnapshot(db);
  const countResult = await db.query("SELECT COUNT(*) AS total FROM fm_snapshots WHERE status = 'verified'");
  const logResult = await db.query('SELECT COUNT(*) AS total FROM fm_audit_events');
  const historyResult = await db.query("SELECT snapshot_id, created_at, key_count, byte_count FROM fm_snapshots WHERE status = 'verified' ORDER BY created_at DESC LIMIT 5");
  const snapshotCount = Number(readRows(countResult)[0]?.total || 0);
  const auditCount = Number(readRows(logResult)[0]?.total || 0);
  summary.replaceChildren();
  const details = [
    ['Snapshot terverifikasi', String(snapshotCount)],
    ['Log aktivitas database', String(auditCount)],
    ['Snapshot terakhir', latest ? new Date(latest.created_at).toLocaleString('id-ID') : 'Belum ada'],
    ['Database', `${DB_NAME} · skema ${DB_VERSION}`],
  ];
  for (const [label, value] of details) {
    const row = document.createElement('div');
    row.className = 'fmdb-summary-row';
    const left = document.createElement('span');
    left.textContent = label;
    const right = document.createElement('strong');
    right.textContent = value;
    row.append(left, right);
    summary.appendChild(row);
  }
  const history = document.getElementById('fmdbHistory');
  if (history) {
    history.replaceChildren();
    const historyTitle = document.createElement('div');
    historyTitle.className = 'fmdb-history-title';
    historyTitle.textContent = 'Snapshot terverifikasi terbaru';
    history.appendChild(historyTitle);
    const snapshots = readRows(historyResult);
    if (!snapshots.length) {
      const empty = document.createElement('div');
      empty.className = 'fmdb-history-empty';
      empty.textContent = 'Belum ada riwayat snapshot.';
      history.appendChild(empty);
    } else {
      for (const item of snapshots) {
        const row = document.createElement('div');
        row.className = 'fmdb-history-row';
        const meta = document.createElement('div');
        meta.className = 'fmdb-history-meta';
        const date = document.createElement('strong');
        date.textContent = new Date(item.created_at).toLocaleString('id-ID');
        const detail = document.createElement('span');
        detail.textContent = `${item.key_count} key · ${formatBytes(item.byte_count)}`;
        meta.append(date, detail);
        const exportOne = makeButton(`fmdbHistory-${item.snapshot_id}`, 'Ekspor', 'quiet', () => exportVerifiedSnapshot(item.snapshot_id));
        row.append(meta, exportOne);
        history.appendChild(row);
      }
    }
  }
  currentSnapshot = latest;
  const exportButton = document.getElementById('fmdbExport');
  if (exportButton) exportButton.disabled = !latest;
}

async function createVerifiedSnapshot() {
  if (busy) return;
  busy = true;
  const createButton = document.getElementById('fmdbCreate');
  if (createButton) createButton.disabled = true;
  let pendingSnapshotId = null;
  try {
    const db = await getDatabase();
    setStatus('Membaca localStorage tanpa mengubah data asli…', 'working');
    const collected = collectStorageEntries(localStorage);
    const envelope = await createSnapshotEnvelope(collected.entries, { appVersion: APP_VERSION });
    pendingSnapshotId = envelope.snapshotId;
    const now = envelope.createdAt;
    const operations = [{
      statement: `INSERT INTO fm_snapshots
        (snapshot_id, format_version, source, created_at, app_version, key_count, byte_count, checksum, status)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'staging')`,
      values: [envelope.snapshotId, envelope.formatVersion, envelope.source, now, envelope.appVersion, envelope.keyCount, envelope.byteCount, envelope.checksum],
    }];
    for (const item of envelope.entries) {
      operations.push({
        statement: `INSERT INTO fm_snapshot_items
          (snapshot_id, storage_key, storage_value, value_sha256, byte_length)
          VALUES (?, ?, ?, ?, ?)`,
        values: [envelope.snapshotId, item.key, item.value, item.valueSha256, item.byteLength],
      });
    }
    setStatus(`Menulis ${envelope.keyCount} key (${formatBytes(envelope.byteCount)}) ke SQLite dalam satu transaksi…`, 'working');
    await db.executeSet(operations);

    const verifyResult = await db.query(
      'SELECT storage_key, storage_value, value_sha256, byte_length FROM fm_snapshot_items WHERE snapshot_id = ? ORDER BY storage_key ASC',
      [envelope.snapshotId],
    );
    const rows = readRows(verifyResult);
    const readback = {
      format: envelope.format,
      formatVersion: envelope.formatVersion,
      snapshotId: envelope.snapshotId,
      createdAt: envelope.createdAt,
      appVersion: envelope.appVersion,
      source: envelope.source,
      keyCount: rows.length,
      byteCount: envelope.byteCount,
      checksum: envelope.checksum,
      entries: rows.map((row) => ({
        key: row.storage_key,
        value: row.storage_value,
        valueSha256: row.value_sha256,
        byteLength: Number(row.byte_length),
      })),
    };
    await verifySnapshotEnvelope(readback);
    if (rows.length !== envelope.keyCount) throw new Error('Jumlah baris yang dibaca ulang berbeda dari jumlah awal.');

    await db.run(
      "UPDATE fm_snapshots SET status = 'verified', verified_at = ?, failure_note = NULL WHERE snapshot_id = ? AND status = 'staging'",
      [new Date().toISOString(), envelope.snapshotId],
    );
    pendingSnapshotId = null;
    await recordAudit(db, 'snapshot_verified', {
      snapshotId: envelope.snapshotId,
      keyCount: envelope.keyCount,
      byteCount: envelope.byteCount,
      checksum: envelope.checksum,
    });
    setStatus(`Snapshot berhasil diverifikasi · ${envelope.keyCount} key · ${formatBytes(envelope.byteCount)} · checksum SHA-256 cocok. Data localStorage asli tidak dihapus.`, 'success');
    await refreshSummary(db);
  } catch (error) {
    if (pendingSnapshotId && dbConnection && dbOpened) {
      try {
        await dbConnection.run(
          "UPDATE fm_snapshots SET status = 'failed', failure_note = ? WHERE snapshot_id = ? AND status = 'staging'",
          [String(error?.message || error).slice(0, 500), pendingSnapshotId],
        );
      } catch (_) { /* Keep an unverified staging row rather than risking another write. */ }
    }
    showError(error);
    try { if (dbConnection && dbOpened) await refreshSummary(dbConnection); } catch (_) { /* Preserve the original error message. */ }
  } finally {
    busy = false;
    if (createButton) createButton.disabled = false;
  }
}

async function loadSnapshotEnvelope(db, snapshotId) {
  const headerResult = await db.query('SELECT * FROM fm_snapshots WHERE snapshot_id = ? AND status = \'verified\' LIMIT 1', [snapshotId]);
  const header = readRows(headerResult)[0];
  if (!header) throw new Error('Snapshot terverifikasi tidak ditemukan.');
  const itemsResult = await db.query(
    'SELECT storage_key, storage_value, value_sha256, byte_length FROM fm_snapshot_items WHERE snapshot_id = ? ORDER BY storage_key ASC',
    [snapshotId],
  );
  const rows = readRows(itemsResult);
  const envelope = {
    format: 'FM_SQLITE_LOCALSTORAGE_SNAPSHOT',
    formatVersion: Number(header.format_version),
    snapshotId: header.snapshot_id,
    createdAt: header.created_at,
    appVersion: header.app_version,
    source: header.source,
    keyCount: Number(header.key_count),
    byteCount: Number(header.byte_count),
    checksum: header.checksum,
    entries: rows.map((row) => ({
      key: row.storage_key,
      value: row.storage_value,
      valueSha256: row.value_sha256,
      byteLength: Number(row.byte_length),
    })),
  };
  const verified = await verifySnapshotEnvelope(envelope);
  if (verified.keyCount !== Number(header.key_count) || verified.byteCount !== Number(header.byte_count)) {
    throw new Error('Metadata snapshot dan isi database tidak cocok.');
  }
  return envelope;
}

async function exportVerifiedSnapshot(snapshotId = null) {
  if (busy) return;
  busy = true;
  const button = document.getElementById('fmdbExport');
  if (button) button.disabled = true;
  try {
    const db = await getDatabase();
    const latest = await latestVerifiedSnapshot(db);
    const selectedId = snapshotId || latest?.snapshot_id;
    if (!selectedId) throw new Error('Belum ada snapshot terverifikasi untuk diekspor.');
    setStatus('Memverifikasi ulang snapshot dari SQLite sebelum ekspor…', 'working');
    const envelope = await loadSnapshotEnvelope(db, selectedId);
    const blob = new Blob([JSON.stringify(envelope, null, 2)], { type: 'application/json;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = `finance-manager-sqlite-snapshot-${envelope.createdAt.slice(0, 10)}.json`;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1500);
    await recordAudit(db, 'snapshot_exported', { snapshotId: envelope.snapshotId, checksum: envelope.checksum });
    setStatus(`Ekspor dibuat setelah verifikasi ulang · ${envelope.keyCount} key · ${formatBytes(envelope.byteCount)}. Simpan file di lokasi aman.`, 'success');
    await refreshSummary(db);
  } catch (error) {
    showError(error);
  } finally {
    busy = false;
    if (button) button.disabled = !(currentSnapshot && currentSnapshot.snapshot_id);
  }
}

function makeButton(id, label, variant, onClick) {
  const button = document.createElement('button');
  button.type = 'button';
  button.id = id;
  button.className = `fmdb-button ${variant || ''}`.trim();
  button.textContent = label;
  button.addEventListener('click', async () => {
    try { await onClick(); } catch (error) { showError(error); }
  });
  return button;
}

function addSettingsCard() {
  const main = document.getElementById('mainView');
  if (!main || document.getElementById('fmSqliteSettingsCard')) return;
  const title = main.querySelector('.page-title');
  if (!title || title.textContent.trim().toLowerCase() !== 'pengaturan') return;

  const card = document.createElement('section');
  card.id = 'fmSqliteSettingsCard';
  card.className = 'card settings-section fmdb-card';
  const heading = document.createElement('h3');
  heading.textContent = 'Database & migrasi SQLite';
  const intro = document.createElement('p');
  intro.className = 'fmdb-intro';
  intro.textContent = 'Ruang backup SQLite native untuk menyalin dan memverifikasi data lama. Database ini belum menggantikan penyimpanan transaksi harian.';
  const status = document.createElement('div');
  status.id = 'fmdbStatus';
  status.className = 'fmdb-status';
  status.dataset.state = 'info';
  status.textContent = Capacitor.isNativePlatform()
    ? 'SQLite native tersedia. Siapkan database untuk memulai.'
    : 'Fitur SQLite native aktif setelah proyek dibangun menjadi APK dan plugin tersinkronisasi.';
  const actions = document.createElement('div');
  actions.className = 'fmdb-actions';
  const prepare = makeButton('fmdbPrepare', 'Siapkan database', 'primary', async () => {
    await initialiseDatabase();
    document.getElementById('fmdbCreate').disabled = false;
  });
  prepare.disabled = !Capacitor.isNativePlatform();
  const create = makeButton('fmdbCreate', 'Salin & verifikasi data lama', 'primary', createVerifiedSnapshot);
  create.disabled = !Capacitor.isNativePlatform() || !dbReady;
  const exportButton = makeButton('fmdbExport', 'Ekspor snapshot terverifikasi', 'secondary', exportVerifiedSnapshot);
  exportButton.disabled = true;
  const refresh = makeButton('fmdbRefresh', 'Perbarui status', 'quiet', async () => {
    const db = await getDatabase();
    await refreshSummary(db);
    document.getElementById('fmdbCreate').disabled = false;
    const latest = await latestVerifiedSnapshot(db);
    setStatus(latest ? `SQLite siap · snapshot terakhir ${latest.key_count} key.` : 'SQLite siap · belum ada snapshot terverifikasi.', 'success');
  });
  refresh.disabled = !Capacitor.isNativePlatform();
  actions.append(prepare, create, exportButton, refresh);
  const summary = document.createElement('div');
  summary.id = 'fmdbSummary';
  summary.className = 'fmdb-summary';
  summary.textContent = 'Database belum disiapkan.';
  const history = document.createElement('div');
  history.id = 'fmdbHistory';
  history.className = 'fmdb-history';
  const warning = document.createElement('div');
  warning.className = 'fmdb-warning';
  warning.textContent = 'PENTING: SQLite tahap ini hanya menyimpan snapshot terverifikasi, belum menjadi sumber transaksi harian. localStorage tetap aktif. Data media/lampiran di IndexedDB belum ikut disalin. Database dan file ekspor belum dienkripsi; file snapshot dapat memuat data keuangan dan hash PIN. Lindungi file tersebut, dan jangan hapus data aplikasi lama atau uninstall APK sebelum backup terpisah diverifikasi.';
  card.append(heading, intro, status, actions, summary, history, warning);
  main.appendChild(card);
}

function installSettingsEntry() {
  const main = document.getElementById('mainView');
  if (!main) return;
  const observer = new MutationObserver(() => addSettingsCard());
  observer.observe(main, { childList: true, subtree: true });
  document.querySelector('.nav-item[data-page="settings"]')?.addEventListener('click', () => queueMicrotask(addSettingsCard));
  addSettingsCard();
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', installSettingsEntry, { once: true });
} else {
  installSettingsEntry();
}

window.FMDatabaseTools = Object.freeze({
  databaseName: DB_NAME,
  schemaVersion: DB_VERSION,
  nativeAvailable: () => Capacitor.isNativePlatform(),
  isReady: () => dbReady,
  verifySnapshotEnvelope,
});
