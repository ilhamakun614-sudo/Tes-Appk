import { Printer } from '@capgo/capacitor-printer';

// Vite bundles this bridge into www/js/fm-sqlite-center.js.
// No CDN, remote script, or runtime network request is used.
if (typeof window !== 'undefined') {
  window.FMNativePrinter = Printer;
  window.FMNativePrinterReady = true;
  window.dispatchEvent(new Event('fm-native-printer-ready'));
}
