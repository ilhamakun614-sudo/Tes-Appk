export const SNAPSHOT_FORMAT = 'FM_SQLITE_LOCALSTORAGE_SNAPSHOT';
export const SNAPSHOT_FORMAT_VERSION = 1;
export const SNAPSHOT_LIMITS = Object.freeze({ maxKeys: 500, maxBytes: 32 * 1024 * 1024 });

function utf8Bytes(value) {
  return new TextEncoder().encode(String(value)).byteLength;
}

function compareKeys(a, b) {
  return a.key < b.key ? -1 : a.key > b.key ? 1 : 0;
}

export function normalizeSnapshotEntries(entries, limits = SNAPSHOT_LIMITS) {
  if (!Array.isArray(entries)) throw new TypeError('Daftar data snapshot harus berupa array.');
  if (entries.length > limits.maxKeys) throw new RangeError(`Jumlah key melebihi batas ${limits.maxKeys}.`);
  const seen = new Set();
  let byteCount = 0;
  const normalized = entries.map((entry) => {
    if (!entry || typeof entry.key !== 'string' || typeof entry.value !== 'string') {
      throw new TypeError('Setiap data harus memiliki key dan value berbentuk teks.');
    }
    if (!entry.key || entry.key.length > 512) throw new TypeError('Nama key kosong atau terlalu panjang.');
    if (seen.has(entry.key)) throw new Error(`Key ganda ditemukan: ${entry.key}`);
    seen.add(entry.key);
    byteCount += utf8Bytes(entry.key) + utf8Bytes(entry.value);
    if (byteCount > limits.maxBytes) throw new RangeError(`Ukuran snapshot melebihi batas ${(limits.maxBytes / 1024 / 1024).toFixed(0)} MiB.`);
    return { key: entry.key, value: entry.value };
  }).sort(compareKeys);
  return { entries: normalized, byteCount };
}

export function collectStorageEntries(storage = globalThis.localStorage, limits = SNAPSHOT_LIMITS) {
  if (!storage || !Number.isInteger(storage.length)) throw new Error('localStorage tidak tersedia.');
  const entries = [];
  let byteCount = 0;
  const count = storage.length;
  if (count > limits.maxKeys) throw new RangeError(`Jumlah key (${count}) melebihi batas aman ${limits.maxKeys}.`);
  for (let index = 0; index < count; index += 1) {
    const key = storage.key(index);
    if (typeof key !== 'string') throw new Error(`Key localStorage pada indeks ${index} tidak dapat dibaca.`);
    const value = storage.getItem(key);
    if (typeof value !== 'string') throw new Error(`Isi localStorage tidak dapat dibaca: ${key}`);
    byteCount += utf8Bytes(key) + utf8Bytes(value);
    if (byteCount > limits.maxBytes) throw new RangeError(`Ukuran data localStorage melebihi batas aman ${(limits.maxBytes / 1024 / 1024).toFixed(0)} MiB.`);
    entries.push({ key, value });
  }
  return normalizeSnapshotEntries(entries, limits);
}

export async function sha256Hex(value) {
  if (!globalThis.crypto?.subtle) throw new Error('SHA-256 tidak tersedia pada perangkat ini.');
  const bytes = new TextEncoder().encode(String(value));
  const digest = await globalThis.crypto.subtle.digest('SHA-256', bytes);
  return [...new Uint8Array(digest)].map((part) => part.toString(16).padStart(2, '0')).join('');
}

export function canonicalSnapshotPayload(entries) {
  const normalized = normalizeSnapshotEntries(entries);
  return JSON.stringify({ format: SNAPSHOT_FORMAT, formatVersion: SNAPSHOT_FORMAT_VERSION, entries: normalized.entries });
}

export async function createSnapshotEnvelope(entries, options = {}) {
  const normalized = normalizeSnapshotEntries(entries, options.limits || SNAPSHOT_LIMITS);
  const hashedEntries = [];
  for (const entry of normalized.entries) {
    hashedEntries.push({
      key: entry.key,
      value: entry.value,
      valueSha256: await sha256Hex(entry.value),
      byteLength: utf8Bytes(entry.key) + utf8Bytes(entry.value),
    });
  }
  const canonical = JSON.stringify({
    format: SNAPSHOT_FORMAT,
    formatVersion: SNAPSHOT_FORMAT_VERSION,
    entries: normalized.entries,
  });
  const checksum = await sha256Hex(canonical);
  const snapshotId = options.snapshotId || (globalThis.crypto?.randomUUID ? globalThis.crypto.randomUUID() : `fm-${Date.now()}-${Math.random().toString(16).slice(2)}`);
  return {
    format: SNAPSHOT_FORMAT,
    formatVersion: SNAPSHOT_FORMAT_VERSION,
    snapshotId,
    createdAt: options.createdAt || new Date().toISOString(),
    appVersion: options.appVersion || '1.0.4',
    source: 'localStorage-read-only-copy',
    keyCount: hashedEntries.length,
    byteCount: normalized.byteCount,
    checksum,
    entries: hashedEntries,
  };
}

export async function verifySnapshotEnvelope(snapshot, options = {}) {
  const limits = options.limits || SNAPSHOT_LIMITS;
  if (!snapshot || snapshot.format !== SNAPSHOT_FORMAT || snapshot.formatVersion !== SNAPSHOT_FORMAT_VERSION) {
    throw new Error('Format snapshot tidak dikenal.');
  }
  if (typeof snapshot.snapshotId !== 'string' || !snapshot.snapshotId || typeof snapshot.checksum !== 'string') {
    throw new Error('Metadata snapshot tidak lengkap.');
  }
  if (!Array.isArray(snapshot.entries) || snapshot.keyCount !== snapshot.entries.length) {
    throw new Error('Jumlah data snapshot tidak cocok.');
  }
  const normalized = normalizeSnapshotEntries(snapshot.entries.map((entry) => ({ key: entry?.key, value: entry?.value })), limits);
  if (normalized.byteCount !== snapshot.byteCount) throw new Error('Ukuran snapshot tidak cocok.');
  for (const entry of snapshot.entries) {
    const expected = await sha256Hex(entry.value);
    if (entry.valueSha256 !== expected) throw new Error(`Checksum isi data tidak cocok: ${entry.key}`);
    const expectedBytes = utf8Bytes(entry.key) + utf8Bytes(entry.value);
    if (entry.byteLength !== expectedBytes) throw new Error(`Ukuran data tidak cocok: ${entry.key}`);
  }
  const canonical = JSON.stringify({
    format: SNAPSHOT_FORMAT,
    formatVersion: SNAPSHOT_FORMAT_VERSION,
    entries: normalized.entries,
  });
  const checksum = await sha256Hex(canonical);
  if (checksum !== snapshot.checksum) throw new Error('Checksum keseluruhan snapshot tidak cocok.');
  return { valid: true, keyCount: normalized.entries.length, byteCount: normalized.byteCount, checksum };
}

export function formatBytes(bytes) {
  const value = Number(bytes);
  if (!Number.isFinite(value) || value < 0) return '—';
  if (value < 1024) return `${value} B`;
  if (value < 1024 * 1024) return `${(value / 1024).toFixed(1)} KB`;
  return `${(value / 1024 / 1024).toFixed(2)} MB`;
}
