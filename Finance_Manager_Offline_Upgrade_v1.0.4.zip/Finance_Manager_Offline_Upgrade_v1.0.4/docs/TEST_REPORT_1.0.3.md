# Laporan Pengujian — Finance Manager Offline 1.0.3

Tanggal: 8 November 2026

## Lulus dalam lingkungan audit

- `npm test` berhasil dijalankan.
- Pemeriksaan sintaks JavaScript dan konfigurasi yang dimuat melalui HTML berhasil.
- Pemeriksaan struktur konfigurasi Capacitor, JSON package, `webDir`, dan aset lokal berhasil.
- Tes snapshot/migrasi SQLite lokal tetap lulus: source localStorage tidak berubah saat pengumpulan, key terurut konsisten, checksum SHA-256 tervalidasi, manipulasi terdeteksi, duplicate key ditolak, dan batas ukuran diterapkan.
- Smoke test SQL SQLite lokal tetap lulus termasuk schema marker, read-back, checksum, status terverifikasi, constraint foreign key, dan CHECK.
- Tes regresi profil: registry rusak tidak ditimpa.
- Tes regresi ledger: pembayaran cicilan yang masih tertaut diblokir dari edit/hapus umum; transaksi dengan marker `obligationPayment` tetap dilindungi setelah catatan kewajiban dihapus.
- Tes kebijakan pelunasan: sumber tidak lagi memuat halaman arsip lunas; pembayaran tetap dimasukkan ke ledger; metadata kewajiban difilter saat lunas; backup lama diverifikasi sebelum pembersihan.
- Tes hapus manual: transaksi terhubung diberi marker dan perubahan ledger + metadata dilakukan dengan `v5WritePair()`.
- Tes konversi budget: helper aktual mengonversi contoh USD ke IDR, mempertahankan IDR, dan mengabaikan nominal invalid.
- Tes agregasi lintas mata uang tambahan: asisten offline memakai konversi saat menghitung total dan mengurutkan transaksi terbesar; laporan tahunan memakai mata uang dasar untuk total/top kategori serta mata uang wallet asli untuk detail; widget harian memakai mata uang dasar.
- Tes hutang/piutang lintas mata uang: cicilan legacy dikonversi dari mata uang wallet ke mata uang kewajiban; cicilan baru memakai nilai ekuivalen yang dibekukan; ringkasan kewajiban untuk modul dan net-worth/health score dikonversi ke mata uang dasar berdasarkan mata uang awal kewajiban.
- Tes backup kewajiban: pembayaran, penghapusan manual, dan pembersihan legacy memakai helper yang memeriksa snapshot ledger dan metadata aktif sebelum mutasi.
- Agregasi utama untuk pemasukan/pengeluaran periode, kategori/tag, grafik dan hit-test interaktif, budget harian/bulanan, widget, laporan terfilter, laporan tahunan, asisten offline, dan ringkasan hutang/piutang/net-worth sudah diarahkan ke helper konversi.

## Belum diverifikasi

- Tidak ada pengujian interaksi browser sungguhan/DOM penuh untuk form pelunasan, hapus manual, atau halaman budget.
- Build Vite dan integrasi plugin Capacitor SQLite native belum dilakukan pada sesi audit ini. Registry npm tidak terjangkau (`EAI_AGAIN`) pada percobaan build sebelumnya; output bundle `www/js/fm-sqlite-center.js` perlu dibuat sebelum `cap sync`.
- `package-lock.json` belum tersedia.
- Belum ada build APK atau tes Android/WebView/perangkat fisik.
- Belum dilakukan tes crash/restart saat write, storage penuh, ekspor file Android, restore backup end-to-end, atau uji beban data besar.
- SQLite masih snapshot vault, bukan live transaction database.
- Kurs historis belum dikunci per transaksi.

## Kesimpulan

Patch 1.0.3 lulus pemeriksaan statis/regresi yang tersedia di repository. Ini bukan sertifikasi bebas bug dan bukan bukti siap rilis APK. Uji perangkat dan build native tetap wajib sebelum mengganti versi aplikasi yang berisi data asli.
