# Audit & Roadmap — Finance Manager Offline 1.0.3

Tanggal: 8 November 2026  
Sumber: ZIP proyek asli pengguna dan revisi audit 1.0.1–1.0.3.

## Kesimpulan

Banyak kapabilitas A–E telah ada di kode sebelum upgrade ini. Karena itu versi 1.0.3 tidak membuat ulang modul wallet, budget, goals, recurring, utang/piutang, cicilan, laporan, multi-currency, PIN, backup/restore, CSV, media, assistant, theme, serta beragam modul perencanaan. Fokus patch hanya pada temuan logika dan integritas yang nyata.

**SQLite masih menjadi snapshot vault terverifikasi, belum database transaksi utama.** Sumber transaksi aktif masih `localStorage`; data media/attachment sebagian berada di IndexedDB.

## Hasil audit dan status

| Area | Implementasi yang ditemukan | Temuan / status |
|---|---|---|
| Keuangan dasar | Wallet, pemasukan, pengeluaran, transfer, kategori, budget | Ada. Agregasi budget dan ringkasan multi-mata-uang diperbaiki di 1.0.3 agar memakai kurs wallet offline ke mata uang dasar. |
| Perencanaan | Target, transaksi berulang, langganan, kalender/proyeksi, envelope, simulasi 12 bulan | Ada. Tidak dibuat ulang; butuh pengujian runtime untuk memastikan jalur jadwal/idempotensi. |
| Hutang/piutang | Catatan, cicilan, jadwal, notifikasi in-app, ringkasan | Ada. Kebijakan disesuaikan: saat lunas metadata kewajiban dihapus otomatis setelah backup penuh terverifikasi; transaksi pembayaran tetap di ledger dan tetap dilindungi. Cicilan lintas mata uang dihitung ke mata uang kewajiban dan snapshot baru dibekukan saat pembayaran. Tidak ada arsip lunas. |
| Penghapusan kewajiban | Fungsi delete sudah ada tetapi sebelumnya menolak catatan yang punya cicilan dan tidak tampil di layar detail KWH | 1.0.3 menambahkan tombol hapus di detail dan mengizinkan penghapusan metadata setelah backup terverifikasi; transaksi pembayarannya tidak dihapus dan diberi marker perlindungan. |
| Ledger protection | Guard transaksi terkait cicilan | Guard yang tersambung ke fungsi transaksi diperbaiki pada 1.0.1; 1.0.3 mempertahankan proteksi setelah metadata kewajiban dihapus. |
| Laporan | Laporan bulanan/tahunan, grafik, analisis, net worth snapshot, tutup buku | Banyak tersedia. Ini bukan akuntansi formal double-entry; neraca akuntansi berbasis chart of accounts belum tersedia. |
| Multi-mata-uang | Kode mata uang wallet, mata uang dasar, kurs manual offline, laporan konversi | Ada. Agregasi utama, budget, kategori, grafik interaktif, laporan statistik/tahunan, asisten offline, widget, dan ringkasan kewajiban/net-worth diperbaiki pada 1.0.3. Snapshot ekuivalen cicilan baru dibekukan pada saat bayar; kurs historis transaksi reguler serta cicilan lama belum dikunci. |
| Backup/restore | JSON, CSV, backup terenkripsi AES-GCM/PBKDF2, pemulihan atomik, media IndexedDB | Sudah ada. Jalur berbeda punya tujuan berbeda; tidak diduplikasi. Uji perangkat end-to-end tetap perlu dilakukan. |
| Profil | Multi-profil, pemisahan state, media per profil | Ada. Proteksi registry rusak agar tidak ditimpa sudah ditambahkan sebelumnya. Perlu uji multi-profil dengan backup/restore di perangkat. |
| Keamanan | PIN, auto-lock, backup terenkripsi | Ada, tetapi PIN hanya mengunci tampilan dan bukan enkripsi `localStorage`. Database aktif tidak terenkripsi at-rest; biometrik native belum ada. |
| Notifikasi | Pengingat dalam aplikasi | Ada. Penjadwalan native yang andal saat aplikasi tertutup belum tersedia/terverifikasi. |
| SQLite | Plugin native dan snapshot vault | Ada sebagai snapshot salinan yang diverifikasi SHA-256. Belum live transaction store; tidak ada cutover domain. |
| APK/build | Capacitor + Vite + workflow build | Sumber build tersedia. Vite bundle belum dibangun pada sesi audit; dependency lockfile belum ada; APK belum diuji. |

## Perubahan 1.0.3

1. Menghapus otomatis metadata utang/piutang saat saldo mencapai nol. Pembayaran masuk ke ledger; payment row tetap dilindungi setelah catatan dibuang.
2. Membersihkan kewajiban lama yang telah lunas hanya setelah backup penuh diverifikasi terhadap raw key aktif. Jika backup gagal/tidak cocok, pembersihan ditahan.
3. Menambahkan hapus manual di detail catatan, termasuk untuk catatan yang punya cicilan. Metadata kewajiban yang dihapus tidak menghapus transaksi wallet.
4. Menyamakan konversi mata uang pada budget, pemasukan/pengeluaran periode, ringkasan kategori, grafik donat, widget, dan ringkasan hutang/piutang.
5. Merekam kode mata uang awal kewajiban dan snapshot ekuivalen pembayaran lintas mata uang untuk cicilan baru.
6. Memastikan laporan statistik/tahunan, asisten offline, widget, grafik interaktif, serta ringkasan net-worth/health score memakai konversi multi-mata-uang yang sama.
7. Tidak menambah modul A–E yang telah ada dan tidak mengubah skema utama data transaksi.

## Pekerjaan yang benar-benar masih kurang

### P0 — Integritas & platform
- Migrasi domain SQLite: wallet, kategori, transaksi, transfer, kewajiban, pembayaran, budget, profil, recurring, dan media. Wajib copy → verify jumlah & total → commit, simpan rollback, tanpa hapus sumber sebelum tes Android lolos.
- Kurs historis per transaksi agar perubahan kurs manual tidak mengubah laporan masa lalu.
- Build lockfile reproducible (`package-lock.json`, lalu `npm ci`) dan jalankan build + tes pada CI.
- Tes Android/WebView: transaksi, pelunasan, restore, backup file, crash saat write, low storage, upgrade tanpa uninstall, multi-profil, dan media.

### P1 — Akuntansi (hanya bila targetnya akuntansi usaha penuh)
- Chart of accounts dan jurnal debit/kredit.
- Jurnal koreksi berbasis reversal/void dan audit trail alasan/perubahan.
- Neraca formal, laba rugi berbasis akun, dan arus kas yang bisa direkonsiliasi.

Fitur tersebut bukan duplikasi laporan yang sudah ada; ini lapisan akuntansi berbeda. Tidak ditambahkan pada 1.0.3 karena butuh desain ledger dan migrasi terpisah.

### P2 — Keamanan & kenyamanan platform
- Enkripsi data aktif at-rest dengan pengelolaan kunci yang realistis; PIN saat ini bukan enkripsi.
- Integrasi biometrik native bila tersedia di perangkat.
- Scheduler notifikasi native untuk pengingat saat aplikasi tertutup.
- Pemadatan/pagination data besar dan uji performa di perangkat target.

## Catatan mata uang

Kurs yang dipakai saat ini merupakan nilai bawaan/override offline. Tidak ada feed real-time. 1.0.3 mengonversi agregasi inti ke mata uang dasar. Cicilan baru menyimpan nominal ekuivalen pada mata uang kewajiban saat dibayar; pembayaran legacy dan transaksi reguler belum menyimpan snapshot kurs. Mengganti kurs wallet dapat mengubah hasil ekuivalen historis untuk data lama.

## Validasi yang dilakukan

`npm test` mencakup pemeriksaan sintaks/aset, tes inti snapshot/SQLite lokal, proteksi registry profil, proteksi ledger cicilan, kebijakan hapus otomatis, safe manual delete, dan tes helper konversi mata uang. Tidak ada klaim bahwa tes tersebut menggantikan pengujian browser atau Android.

Detail lihat `docs/TEST_REPORT_1.0.3.md` dan perubahan lihat `docs/UPGRADE_NOTES_1.0.3.md`.
