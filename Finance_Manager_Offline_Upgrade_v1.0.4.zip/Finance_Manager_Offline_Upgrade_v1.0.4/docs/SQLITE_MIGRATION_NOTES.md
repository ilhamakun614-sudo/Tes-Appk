# SQLite migration notes — updated for 1.0.2

## Verified from source

- Main application data key: `finance_v1`.
- Last backup key: `finance_backup_last`.
- Recovery journal key: `fm_v12_restore_journal`.
- The app stores finance state in many `localStorage` keys and media/attachments in multiple `IndexedDB` stores.
- App transaction reads/writes remain synchronous; a native SQLite bridge is asynchronous.

## Implemented in 1.0.2

- A Capacitor SQLite database named `FinanceManagerOfflineVault` is created from the Settings migration panel.
- Versioned metadata, immutable snapshot header/item tables, and migration audit events are created.
- All current `localStorage` key/value pairs can be copied read-only into one SQLite snapshot.
- The snapshot is written as a batch, read back, and verified with per-value and overall SHA-256 checksums before status becomes `verified`.
- Prior verified snapshots remain stored. Export re-reads and verifies the selected snapshot before generating JSON.
- Source `localStorage` is not deleted or changed by this panel.

## Still not done

- SQLite is not the live source of truth for daily transactions.
- No normalized domain tables exist yet for wallets, transactions, transfers, budgets, recurring rules, obligations/payments, profiles, goals, learning/AI modules, or attachments.
- IndexedDB media/attachment stores are not migrated into SQLite.
- No complete before/after reconciliation of domain records and balances has been run.
- No restore-overwrite path is exposed.
- SQLite encryption is not enabled.

## Required next sequence

1. Enumerate every persisted key, module schema, profile-scoped key, and IndexedDB store.
2. Design versioned domain tables, constraints, unique indexes, foreign keys, and atomic repository operations.
3. Replace synchronous storage calls feature by feature with awaited database repositories; keep a compatibility read-only layer during migration.
4. Import into a new DB in transactions while preserving original localStorage and IndexedDB.
5. Re-read every table and compare record counts, IDs, monetary totals, wallet balances, transfer pairs, obligation/payment links, profile isolation, and media hashes.
6. Test app-kill/restart during writes, storage pressure, rollback, backup, and restore on real Android devices.
7. Only after repeated successful device tests should SQLite become primary.

Never run destructive cleanup merely because database initialization or snapshot verification succeeded.
