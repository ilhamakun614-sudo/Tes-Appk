# Test report — Finance Manager Offline 1.0.2

Date: 8 November 2026

## Passed

- `npm test` static project checks passed.
- JavaScript syntax checks passed for the existing app scripts, migration source modules, and Vite config.
- Snapshot-core tests passed: source `localStorage` remains unchanged, keys are consistently sorted, SHA-256 and count/size metadata verify, tampering is detected, duplicate keys are rejected, and limits are enforced.
- Previous regression tests passed: corrupt profile registry is not overwritten; linked installment ledger entries are protected; paid obligation archive guards remain present.
- SQLite DDL smoke test passed with local SQLite: table creation, schema marker insertion, snapshot/item insertion, read-back hash and byte-length checks, verified status, foreign-key `RESTRICT`, and checksum-length constraint. The app explicitly enables `PRAGMA foreign_keys` outside a transaction and checks the returned state before creating/using the schema; the native bridge behavior still requires Android verification.
- All declared local CSS/JS references other than the generated Vite bundle resolve to files in the package.

## Warnings / not verified

- The Vite bundle `www/js/fm-sqlite-center.js` has not been generated in this environment. `npm install --package-lock-only` was attempted but npm could not resolve `registry.npmjs.org` (`EAI_AGAIN` DNS failure), so no dependency installation or `npm run build` was completed. Run `npm install`, `npm run build`, then `npm test` before `npx cap sync android`.
- `package-lock.json` is not included; exact top-level package versions are pinned, but transitive dependency resolution is not fully reproducible. Generate and review the lockfile in the official build environment before switching workflow to `npm ci`.
- Capacitor SQLite native bridge calls have not been exercised on Android. The local SQLite smoke test validates SQL syntax/constraints, not the plugin bridge.
- No APK build, Android WebView interaction test, Vivo device test, app-kill/restart test, large-data test, or end-to-end backup/restore test was performed. The JSON download action also needs a real Android test before being used as the only backup route.
- IndexedDB attachments/media are not part of the SQLite snapshot.
- SQLite is not the live transaction database and is not encrypted in this release.

This report is a record of the checks actually run; it is not a claim that the app is bug-free or release-ready.
