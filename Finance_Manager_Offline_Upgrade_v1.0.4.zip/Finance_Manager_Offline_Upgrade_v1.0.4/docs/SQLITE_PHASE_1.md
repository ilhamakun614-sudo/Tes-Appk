# SQLite Phase 1 — verified snapshot vault

## Scope

This phase adds a real native SQLite database through `@capacitor-community/sqlite` and a Settings screen entry named **Database & migrasi SQLite**.

The SQLite database is a **verified snapshot vault**, not yet the live source of truth for transactions. The existing app still uses its synchronous `localStorage` APIs for daily reads/writes. This boundary is deliberate: changing synchronous persistence to an asynchronous native database requires a separate, audited storage-adapter migration and device regression tests.

## Tables

- `fm_schema_migrations`: applied schema versions.
- `fm_snapshots`: immutable snapshot headers and verification state.
- `fm_snapshot_items`: original localStorage keys/values and per-value SHA-256 hashes.
- `fm_audit_events`: append-only records for snapshot verification/export actions.

Each snapshot uses a single `executeSet` batch. Foreign-key enforcement is enabled outside a transaction and read back from the same connection. The snapshot is then read back from SQLite and checked against every per-value hash, key count, byte count, and the full snapshot checksum before its status becomes `verified`. Previous verified snapshots are not deleted when a new snapshot is created.

## Safety rules

1. The migration is user-triggered from Settings; it does not run silently on startup.
2. Source localStorage is read-only during the process. No old key is removed or rewritten.
3. Maximum source size: 500 keys and 32 MiB of UTF-8 key/value content.
4. A new snapshot is not marked verified until read-back verification passes.
5. A failed or incomplete snapshot is not allowed to replace an earlier verified snapshot.
6. Export re-reads and re-verifies the stored snapshot before creating JSON.
7. No restore-overwrite operation is exposed in this phase.
8. Existing IndexedDB media/attachment stores are not migrated by this phase.
9. Database encryption is not enabled. Do not represent the SQLite snapshot vault as encrypted. Exported snapshots may contain personal financial records and PIN hashes; protect the file accordingly.
10. SQLite foreign-key enforcement is explicitly turned on for each opened connection and checked before use.

## Build

The SQLite management module imports Capacitor packages and must be bundled before `cap sync`:

```sh
npm install
npm run build
npm test
npx cap sync android
```

The GitHub Actions workflow runs the same Vite build before project verification and APK packaging.

## Next phase before SQLite becomes primary

- Enumerate and validate every localStorage and IndexedDB store, including profile-scoped and dynamic keys.
- Model domain tables for accounts/wallets, categories, transactions, transfers, recurring rules, obligations, payments, budgets, attachments, and profile metadata.
- Implement a repository boundary and migrate each synchronous feature flow to awaited persistence with atomic multi-row transactions.
- Reconcile counts, primary keys, wallet balances, transfer pairs, obligation balances, payment links, and profile isolation.
- Test app-kill/restart during writes, low-storage conditions, interrupted migrations, restore and rollback on real Android devices.
- Keep a verified export and the old storage untouched until all acceptance tests pass.

## Limitations

This phase creates and verifies a native SQLite copy, but it does not make SQLite the live transaction database. It does not provide encryption, automatic background synchronization, or a full business-event audit log. The app's existing IndexedDB media is still stored separately.
