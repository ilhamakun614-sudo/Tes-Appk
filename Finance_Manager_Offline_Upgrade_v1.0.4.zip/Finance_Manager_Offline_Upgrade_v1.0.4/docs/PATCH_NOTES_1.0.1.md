# Patch Notes — 1.0.1

- Memindahkan pengaman transaksi yang terhubung ke cicilan ke dalam ruang lingkup aplikasi yang benar.
- Menyimpan catatan yang telah lunas sebagai arsip, bukan menghapus metadata kewajiban dan riwayat cicilannya.
- Menambahkan layar `Riwayat Lunas` yang dapat dibuka dari halaman Hutang & Piutang.
- Memblokir penghapusan catatan kewajiban yang masih memiliki pembayaran tercatat.
- Membuat pemuatan registry profil gagal secara aman: data registry yang rusak tidak otomatis ditimpa dengan profil baru, dan operasi profil dikunci.
- Menghapus teks `\n` literal yang nyasar di HTML.
- Menghapus `app-03.js` yang guard-nya tidak dapat mengakses fungsi privat aplikasi.
- Menambahkan `npm test` untuk pemeriksaan statis proyek dan menjalankannya pada workflow build APK.

Tidak ada perubahan skema penyimpanan utama, key localStorage, atau migrasi ke SQLite pada patch ini.
