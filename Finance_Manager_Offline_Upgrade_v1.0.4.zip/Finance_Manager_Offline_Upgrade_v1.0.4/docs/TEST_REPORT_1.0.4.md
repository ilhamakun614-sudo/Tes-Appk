# Laporan Patch & Pengujian — Finance Manager Offline 1.0.4

Tanggal: 8 November 2026

## Bug yang ditangani

Tombol `Cetak / Simpan PDF` di panel PDF halaman Statistik sebelumnya hanya memanggil `window.print()`. Pada lingkungan Android WebView/Capacitor, jalur tersebut tidak menjamin pembukaan dialog cetak native, dan dapat tampak tidak bereaksi.

## Perubahan

- Menambahkan dependency `@capgo/capacitor-printer` versi exact `8.1.8` (major version 8 untuk Capacitor 8).
- Menambahkan `src/print-helper.js` dan mengimpornya dari entry Vite SQLite yang sudah dimuat oleh `index.html`. Dengan ini plugin printer dibundel ke aset lokal `www/js/fm-sqlite-center.js`; tidak menambah CDN atau kebutuhan internet saat aplikasi berjalan.
- Mengubah handler Statistik menjadi async, membuat dokumen HTML laporan mandiri dengan CSS cetak, lalu memanggil `Printer.printHtml()`.
- Fallback browser tetap tersedia. Pada platform native ketika bridge plugin tidak tersedia, pengguna menerima pesan yang menjelaskan langkah perbaikannya.
- Tombol dikunci selama proses agar tidak dipencet berulang dan dikembalikan lagi setelah proses selesai.
- Data transaksi, rumus laporan, filter periode, dan penyimpanan tidak diubah.

## Lulus di lingkungan audit

- `node --check www/js/app-01.js`.
- `node --check src/sqlite-center.js`.
- `node --check src/print-helper.js`.
- `npm test` — struktur project, sintaks, dan tes regresi yang tersedia.
- Verifier tambahan memastikan dependency printer terdaftar, bridge terhubung ke entry Vite, handler Statistik memakai `printHtml`, dan fallback native menjelaskan ketika plugin belum aktif.
- Pemeriksaan konfigurasi memastikan semua aset referensi lokal tersedia pada source project.

## Belum dapat diverifikasi

- `npm install`, `npm run build`, dan `npx cap sync android` tidak dapat dijalankan karena akses DNS ke `registry.npmjs.org` gagal (`EAI_AGAIN`) pada lingkungan audit.
- APK Android belum dibangun dan dialog PrintManager belum diuji langsung pada perangkat fisik. Karena itu patch kode dan wiring sudah disiapkan, tetapi keberhasilan dialog native tetap perlu dikonfirmasi setelah dependency terpasang, Vite build, Capacitor sync, dan APK dibangun ulang.
- Pengujian browser sungguhan juga belum tersedia di lingkungan ini.

## Langkah build

```sh
npm install
npm run build
npm test
npx cap sync android
```

Kemudian rebuild APK di Android Studio atau jalankan workflow CI. Jangan menghapus data aplikasi lama; patch ini tidak mengubah skema atau data transaksi.

## Referensi teknis

- Android `WebView.createPrintDocumentAdapter()` menyediakan adapter untuk mencetak isi WebView: https://developer.android.com/reference/android/webkit/WebView
- Android `PrintManager.print()` membuka dialog cetak sistem: https://developer.android.com/reference/android/print/PrintManager
- `@capgo/capacitor-printer` mendukung `printHtml()` via PrintManager Android dan dialog browser pada web: https://capgo.app/docs/plugins/printer/getting-started/
