# Upgrade Notes 1.0.2

## Added

- Native SQLite snapshot vault using the installed Capacitor SQLite plugin.
- Settings panel for database initialization, source snapshotting, read-back verification, snapshot history summary, and verified JSON export.
- Versioned SQLite schema, integrity constraints, indexes, schema migration marker, and administrative audit events.
- SHA-256 checks for each storage value and the canonical full snapshot.
- Explicit per-connection SQLite foreign-key activation and verification.
- Read-only source collection with a 500-key / 32 MiB limit.
- Existing verified snapshots are retained; incomplete snapshots do not replace them.
- Vite build step bundles the plugin code before Capacitor sync.

## Preserved

- Existing `app-01.js`, `app-02.js`, CSS, transaction workflows, and synchronous storage remain in place.
- Existing localStorage keys and IndexedDB media stores are not automatically migrated, deleted, or rewritten.
- Existing backup, restore, import, export, and recovery flows are not replaced.

## Explicitly not claimed

- SQLite is not yet the live source of truth for transactions.
- Full transaction audit trail is not yet implemented.
- Snapshot vault encryption is not enabled.
- IndexedDB attachments/media are not included in the SQLite snapshot.
- Android APK execution, native plugin integration, and device-level regression are not verified in this environment.
