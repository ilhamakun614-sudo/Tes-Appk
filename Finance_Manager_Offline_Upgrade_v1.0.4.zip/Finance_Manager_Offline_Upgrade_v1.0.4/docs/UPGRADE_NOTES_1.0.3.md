# Upgrade Notes 1.0.3 — audit terarah tanpa duplikasi

## Perbaikan yang benar-benar dilakukan

### 1. Utang/piutang otomatis bersih setelah lunas
- Ketika pembayaran terakhir membuat sisa <= toleransi pembulatan Rp0,001, metadata kewajiban dikeluarkan dari `v5State.obligations` pada write yang sama dengan transaksi ledger.
- Tidak ada lagi menu/halaman `Riwayat Lunas`.
- Untuk data lunas yang diwarisi dari versi sebelumnya, aplikasi membuat backup penuh terlebih dahulu, lalu membandingkan salinan `localFinanceStorage[V5_STORAGE_KEY]` dengan nilai storage aktif. Jika backup tidak tersedia atau tidak cocok, pembersihan dibatalkan.
- Pembayaran historis yang punya `transactionId` tetap di ledger. Baris transaksi diberi `obligationPayment=true` agar proteksi edit/hapus umum tetap berlaku setelah metadata kewajiban dibuang.
- Pembayaran terakhir diberi `obligationSettlement=true` agar pencapaian pelunasan tetap dapat dihitung setelah kewajiban dihapus.

### 2. Penghapusan manual catatan
- Tombol `Hapus catatan` ditambahkan ke halaman detail kewajiban.
- Catatan yang pernah dicicil tetap dapat dihapus secara manual setelah backup penuh berhasil diverifikasi.
- Semua transaksi ledger yang terkait diberi marker perlindungan dan kedua penyimpanan diperbarui memakai `v5WritePair()` dengan jurnal pemulihan.
- Tidak ada transaksi pembayaran yang ikut dihapus.

### 3. Konsistensi multi-mata-uang
- Menambahkan helper `fmBudgetConvertedAmount()` untuk mengonversi nominal transaksi dari mata uang wallet ke `v4Meta.baseCurrency` menggunakan kurs offline tersimpan.
- Helper dipakai pada budget per kategori dan bulan berjalan, pengeluaran hari ini, widget dashboard, total pemasukan/pengeluaran periode, ringkasan kategori/tag, grafik donat beserta hit-test area interaktifnya, dan tampilan statistik.
- Laporan statistik terfilter dan laporan tahunan PDF menghitung total/top kategori dalam mata uang dasar; rincian transaksi tahunan tetap ditampilkan dalam mata uang wallet masing-masing.
- Asisten offline mengonversi agregasi, budget, ranking transaksi terbesar, dan kategori boros ke mata uang dasar; nominal setiap transaksi pada daftar tetap ditampilkan dalam mata uang wallet asal.
- Teks asisten budget yang sebelumnya menolak membandingkan nominal lintas mata uang diperbarui karena agregasinya sekarang memakai konversi.
- Nominal asli setiap transaksi tetap disimpan dan ditampilkan pada konteks riwayat transaksi; data transaksi lama tidak ditulis ulang hanya untuk mengubah nominal.

### 4. Konsistensi hutang/piutang lintas mata uang
- Setiap catatan kewajiban menyimpan kode mata uang awal wallet saat dibuat, sehingga perubahan pengaturan mata uang wallet tidak mengganti satuan nominal kewajiban secara diam-diam.
- Pembayaran dari wallet bermata uang lain dikonversi ke satuan kewajiban dengan kurs offline tersimpan. Ledger tetap mencatat nominal asli sesuai mata uang wallet pembayar.
- Setiap cicilan baru menyimpan `obligationAmount`, `obligationCurrency`, dan `transactionCurrency`; nilai ekuivalen kewajiban dibekukan pada saat pembayaran agar perubahan kurs berikutnya tidak mengubah sisa cicilan baru.
- Cicilan lama yang tidak memiliki snapshot ekuivalen dikonversi berdasarkan kurs tersimpan saat ini; hasil historisnya tetap dapat berubah karena versi lama tidak menyimpan kurs tanggal pembayaran.
- Ringkasan total hutang/piutang dan terlambat, serta ringkasan kewajiban yang dipakai kalkulasi net-worth/health score, dikonversi memakai mata uang awal kewajiban ke mata uang dasar; kartu dan detail kewajiban tetap menampilkan satuan asli kewajiban.
- Pembayaran, penghapusan manual, dan pembersihan catatan lunas sekarang mensyaratkan backup penuh yang memuat snapshot ledger serta metadata kewajiban aktif yang cocok.

## Fitur yang sengaja tidak dibuat ulang

Audit kode menemukan implementasi untuk wallet, transfer, kategori, budget, target tabungan, recurring, langganan, hutang/piutang dan cicilan, laporan/grafik, multi-mata-uang, PIN/kunci otomatis, lampiran struk/media, backup/restore/CSV, multi-profil, asisten offline, tema, kalender/proyeksi, rekonsiliasi CSV, simulasi Snowball/Avalanche, tutup buku, envelope budget, simulasi 12 bulan, aset, split bill, proteksi/asuransi, garansi/perawatan, perbandingan kredit, dan snapshot kekayaan bersih. Implementasi yang sudah ada tidak diduplikasi.

Inventaris ini menunjukkan keberadaan kode/fitur, bukan bukti bahwa seluruh jalur sudah lolos pengujian perangkat.

## Tidak diubah pada versi ini

- Struktur utama `localStorage` dan skema modul lama.
- Mekanisme backup/restore utama, format JSON, dan arsip media IndexedDB.
- Plugin SQLite snapshot vault; SQLite tetap belum menjadi live transaction store.
- UI/tema global di luar layar hutang/piutang yang memang diperlukan untuk kebijakan hapus otomatis.
- Fitur yang sudah ada pada A–E selain perbaikan agregasi multi-mata-uang di atas.

## Temuan tersisa / pekerjaan berikutnya

1. Migrasi transaksi, wallet, kategori, profil, kewajiban, pembayaran, dan media ke tabel SQLite sebagai sumber aktif (P0, perlu copy-verify-commit dan rollback perangkat).
2. Kurs historis belum disimpan per transaksi; laporan lama dapat berubah ketika kurs offline diperbarui.
3. PIN masih merupakan pengunci tampilan dan hash PIN lama belum setara dengan skema KDF modern; localStorage aktif belum terenkripsi.
4. Notifikasi native yang dijadwalkan saat aplikasi tertutup belum diimplementasikan/diuji.
5. Belum ada chart of accounts dan jurnal double-entry. Jika targetnya akuntansi usaha penuh, ini fitur baru yang perlu desain khusus, bukan duplikasi halaman laporan sekarang.
6. Build/APK Android dan uji WebView nyata belum selesai karena paket npm tidak dapat diunduh dari lingkungan ini (`EAI_AGAIN` pada npm registry di sesi build sebelumnya). `package-lock.json` belum tersedia.

## Catatan FX

Nilai yang dikonversi memakai kurs tersimpan offline, bukan kurs real-time. Pengguna perlu mengelola kurs wallet di Pengaturan. Penguncian kurs pada tanggal transaksi (historical FX) tetap menjadi pekerjaan terpisah agar nilai historis tidak berubah saat kurs diedit.
