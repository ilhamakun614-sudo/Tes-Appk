# Patch Notes 1.0.4 — Tombol Cetak Statistik

## Gejala
Tombol `Cetak / Simpan PDF` tidak membuka dialog dan tidak memberi respons pada aplikasi Android.

## Penyebab teknis yang paling mungkin
Handler hanya mengandalkan `window.print()`. Itu cocok untuk browser desktop, tetapi bukan kontrak pemanggilan layanan cetak Android native dari Capacitor WebView. Pada WebView, pemanggilan dapat gagal membuka dialog tanpa exception yang bisa ditangkap.

## Patch
1. Integrasikan `@capgo/capacitor-printer` 8.1.8, sesuai major Capacitor 8.
2. Bundel bridge printer ke satu entry Vite yang sudah diload secara lokal oleh halaman.
3. Buat HTML mandiri dari laporan Statistik beserta CSS, tidak menyalin keseluruhan UI aplikasi.
4. Kirim dokumen ke `Printer.printHtml()` untuk memakai dialog cetak native Android.
5. Fallback browser dipertahankan. Platform native tanpa plugin mendapat pesan yang jelas, bukan diam.

## Batas pengujian
Patch belum diuji dengan APK/perangkat nyata karena npm registry tidak bisa dijangkau dari lingkungan kerja. Setelah `npm install`, jalankan `npm run build`, `npm test`, `npx cap sync android`, lalu bangun APK baru.
